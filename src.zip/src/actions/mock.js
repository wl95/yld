module.exports = {
  "innerCode": 100,
  "total": 160,
  "totalPage": 16,
  "data": [
      {
          "ORGAN_ID": "14012817",
          "ORGAN_NAME": "山西省分行",
          "QUOTA": "1201380.0"
      },
      {
          "ORGAN_ID": "14012817",
          "ORGAN_NAME": "山西省分行",
          "QUOTA": "1441656.0"
      },
      {
          "ORGAN_ID": "14012817",
          "ORGAN_NAME": "山西省分行",
          "QUOTA": "840966.0"
      },
      {
          "ORGAN_ID": "14012817",
          "ORGAN_NAME": "山西省分行",
          "QUOTA": "1561794.0"
      },
      {
          "ORGAN_ID": "23016187",
          "ORGAN_NAME": "黑龙江省分行",
          "QUOTA": "1081242.0"
      },
      {
          "ORGAN_ID": "23016187",
          "ORGAN_NAME": "黑龙江省分行",
          "QUOTA": "600690.0"
      },
      {
          "ORGAN_ID": "23016187",
          "ORGAN_NAME": "黑龙江省分行",
          "QUOTA": "480552.0"
      },
      {
          "ORGAN_ID": "23016187",
          "ORGAN_NAME": "黑龙江省分行",
          "QUOTA": "840966.0"
      },
      {
          "ORGAN_ID": "37000013",
          "ORGAN_NAME": "青岛分行",
          "QUOTA": "1561794.0"
      },
      {
          "ORGAN_ID": "37000013",
          "ORGAN_NAME": "青岛分行",
          "QUOTA": "1922208.0"
      }
  ]
}