const SERVER_HOST = 'http://10.136.1.216:9091/'   
const apiPrefix =  SERVER_HOST + 'report/static/organ'
const apiPrefixDict =  SERVER_HOST + 'reportDict/static/organ'

module.exports = {
  apiPrefix,
  apiPrefixDict
}
