const SERVER_HOST = 'http://10.136.1.216:9091/'   
const apiPrefix =  SERVER_HOST + 'report/static/organ'
const apiPrefixV1 =  SERVER_HOST + 'v1'

module.exports = {
  apiPrefix,
  apiPrefixV1
}
